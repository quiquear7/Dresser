package com.uc3m.dresser.database

 class Combinacion(
        var parteSuperior: Prenda?,
        var parteInferior: Prenda?,
        var calzado: Prenda?,
        var jerseis: Prenda?,
        var cazadoras: Prenda?,
        var conjuntos: Prenda?
)
