package com.uc3m.dresser.util

class Constants {
    companion object{
        const val OW_URL = "https://api.openweathermap.org"
    }
}