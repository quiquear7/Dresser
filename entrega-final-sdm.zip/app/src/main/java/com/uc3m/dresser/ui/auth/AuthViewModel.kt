package com.uc3m.dresser.ui.auth

import androidx.lifecycle.ViewModel

class AuthViewModel: ViewModel() {

}